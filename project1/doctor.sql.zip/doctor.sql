-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2019 at 07:16 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctor`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `user_name` varchar(20) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`user_name`, `password`) VALUES
('titu', '147'),
('tania', '258'),
('sifat', '369');

-- --------------------------------------------------------

--
-- Table structure for table `cardiologist`
--

CREATE TABLE `cardiologist` (
  `id` varchar(25) NOT NULL,
  `name` varchar(25) NOT NULL,
  `chamber` varchar(500) NOT NULL,
  `time` varchar(20) NOT NULL,
  `day` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cardiologist`
--

INSERT INTO `cardiologist` (`id`, `name`, `chamber`, `time`, `day`) VALUES
('crd101', 'Professor (Dr.) Md. Fakhr', 'Chamber : LABAID CARDIAC HOSPITAL\r\nHouse # 1, Road # 4, Dhanmondi, Dhaka-1205, Bangladesh.\r\nPhone : 8610793-8, 9670210-3, 8631177 (chamber) Mob : 01711-854780', '9.00 am - 11:00 am', 'sat,sun,mon'),
('crd102', 'Dr. H. I. Lutfor Rahman K', 'Chamber: Comfort Diagnostic Centre & Comfort Nursing Home', '3:00 pm - 6:00 pm', 'sat,mon,tues');

-- --------------------------------------------------------

--
-- Table structure for table `dermatologist`
--

CREATE TABLE `dermatologist` (
  `id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `chamber` varchar(500) NOT NULL,
  `time` varchar(20) NOT NULL,
  `day` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dermatologist`
--

INSERT INTO `dermatologist` (`id`, `name`, `chamber`, `time`, `day`) VALUES
('der101', 'Professor Dr. Abdullah-Al-Safi Majumder', 'Popular Diagnostic Centre Ltd – Dhanmondi Branch\r\nHouse # 16, Road # 2, Dhanmondi R/A, Dhaka – 1205', '11 AM-1 PM & 5 PM-7 ', 'wed,thu'),
('der102', 'Professor Dr. Md. Afjalur Rahman', 'Chamber: LABAID CARDIAC HOSPITAL\r\nHouse # 1, Road # 4, Dhanmondi, Dhaka-1205, Bangladesh.', '11 AM-1 PM & 5 PM-7 ', 'sat,sun');

-- --------------------------------------------------------

--
-- Table structure for table `gynecologist`
--

CREATE TABLE `gynecologist` (
  `id` varchar(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `chamber` varchar(500) NOT NULL,
  `time` varchar(25) NOT NULL,
  `day` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gynecologist`
--

INSERT INTO `gynecologist` (`id`, `name`, `chamber`, `time`, `day`) VALUES
('gy101', 'Professor Hasina Banoo', 'Chamber: Labaid Specialized Hospital – Gulshan Branch\r\nHouse # 13/A, Road # 35, Gulshan-2, Dhaka-1212', '6:00 pm - 9:00 pm', 'sun,mon'),
('gy102', 'Professor Dr. Sufia Rahman', 'Chamber1: Euro-Bangla Heart Hospital Ltd.\r\n5/7 Block – D, Lalmatia Dhaka – 1207, Bangladesh', '6:00 pm - 9:00 pm', 'sat,tues');

-- --------------------------------------------------------

--
-- Table structure for table `neurologist`
--

CREATE TABLE `neurologist` (
  `id` varchar(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `chamber` varchar(500) NOT NULL,
  `time` varchar(25) NOT NULL,
  `day` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `neurologist`
--

INSERT INTO `neurologist` (`id`, `name`, `chamber`, `time`, `day`) VALUES
('neu101', ' Professor Dr. Abduz Zaher', 'Chamber: Labaid Hospital Ltd.\r\nHouse # 1, Road # 4, Dhanmondi, Dhaka – 1205', '4:00 pm - 8:00 pm', 'sat,sun,mon'),
('neu102', 'Professor Dr. Abu Zafar', 'Chamber: Ibn Sina Diagnostic & Imaging Center\r\nHouse # 48, Road # 9/A, Dhanmondi, SAtmasjid Road, Dhaka – 1209, Bangladesh', '4:00 pm - 8:00 pm', 'sat,sun,mon');

-- --------------------------------------------------------

--
-- Table structure for table `psychiatrist`
--

CREATE TABLE `psychiatrist` (
  `id` varchar(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `chamber` varchar(500) NOT NULL,
  `time` varchar(20) NOT NULL,
  `day` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `psychiatrist`
--

INSERT INTO `psychiatrist` (`id`, `name`, `chamber`, `time`, `day`) VALUES
('psy101', 'Professor Dr. K.M.H.S. Sirajul Haque', 'Chamber: The Medical Centre\r\nLocation: House# 84, Road# 7/A, Shat Masjid Road, Dhanmondi, Dhaka', '4:00 pm - 8:00 pm', 'sat,fri'),
('psy102', 'Professor Dr. M. Jalaluddin', 'Chamber: Labaid Cardiac Hospital\r\nLocation: House # 1, Road # 4, Dhanmondi, Dhaka – 1205, Bangladesh', '4:00 pm - 8:00 pm', 'wed,thurs');

-- --------------------------------------------------------

--
-- Table structure for table `sifat`
--

CREATE TABLE `sifat` (
  `name` varchar(50) NOT NULL,
  `chamber` varchar(500) NOT NULL,
  `time` varchar(50) NOT NULL,
  `day` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sifat`
--

INSERT INTO `sifat` (`name`, `chamber`, `time`, `day`) VALUES
('Professor Dr. Abu Zafar', 'Chamber: Ibn Sina Diagnostic & Imaging Center\r\nHouse # 48, Road # 9/A, Dhanmondi, SAtmasjid Road, Dhaka – 1209, Bangladesh', '4:00 pm - 8:00 pm', 'sat,sun,mon'),
('Professor Dr. Abdullah-Al-Safi Majumder', 'Popular Diagnostic Centre Ltd – Dhanmondi Branch\r\nHouse # 16, Road # 2, Dhanmondi R/A, Dhaka – 1205', '11 AM-1 PM & 5 PM-7 ', 'wed,thu');

-- --------------------------------------------------------

--
-- Table structure for table `tania`
--

CREATE TABLE `tania` (
  `name` varchar(50) NOT NULL,
  `chamber` varchar(500) NOT NULL,
  `time` varchar(50) NOT NULL,
  `day` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tania`
--

INSERT INTO `tania` (`name`, `chamber`, `time`, `day`) VALUES
('Professor Dr. Abdullah-Al-Safi Majumder', 'Popular Diagnostic Centre Ltd – Dhanmondi Branch\r\nHouse # 16, Road # 2, Dhanmondi R/A, Dhaka – 1205', '11 AM-1 PM & 5 PM-7 ', 'wed,thu'),
('Professor Dr. Abdullah-Al-Safi Majumder', 'Popular Diagnostic Centre Ltd – Dhanmondi Branch\r\nHouse # 16, Road # 2, Dhanmondi R/A, Dhaka – 1205', '11 AM-1 PM & 5 PM-7 ', 'wed,thu'),
('Professor Dr. K.M.H.S. Sirajul Haque', 'Chamber: The Medical Centre\r\nLocation: House# 84, Road# 7/A, Shat Masjid Road, Dhanmondi, Dhaka', '4:00 pm - 8:00 pm', 'sat,fri'),
('Professor (Dr.) Md. Fakhr', 'Chamber : LABAID CARDIAC HOSPITAL\r\nHouse # 1, Road # 4, Dhanmondi, Dhaka-1205, Bangladesh.\r\nPhone : 8610793-8, 9670210-3, 8631177 (chamber) Mob : 01711-854780', '9.00 am - 11:00 am', 'sat,sun,mon');

-- --------------------------------------------------------

--
-- Table structure for table `titu`
--

CREATE TABLE `titu` (
  `name` varchar(50) NOT NULL,
  `chamber` varchar(500) NOT NULL,
  `time` varchar(50) NOT NULL,
  `day` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `titu`
--

INSERT INTO `titu` (`name`, `chamber`, `time`, `day`) VALUES
(' Professor Dr. Abduz Zaher', 'Chamber: Labaid Hospital Ltd.\r\nHouse # 1, Road # 4, Dhanmondi, Dhaka – 1205', '4:00 pm - 8:00 pm', 'sat,sun,mon'),
('Professor Dr. Sufia Rahman', 'Chamber1: Euro-Bangla Heart Hospital Ltd.\r\n5/7 Block – D, Lalmatia Dhaka – 1207, Bangladesh', '6:00 pm - 9:00 pm', 'sat,tues'),
(' Professor Dr. Abduz Zaher', 'Chamber: Labaid Hospital Ltd.\r\nHouse # 1, Road # 4, Dhanmondi, Dhaka – 1205', '4:00 pm - 8:00 pm', 'sat,sun,mon'),
(' Professor Dr. Abduz Zaher', 'Chamber: Labaid Hospital Ltd.\r\nHouse # 1, Road # 4, Dhanmondi, Dhaka – 1205', '4:00 pm - 8:00 pm', 'sat,sun,mon');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
